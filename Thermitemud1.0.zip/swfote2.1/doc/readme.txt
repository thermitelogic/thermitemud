 ****************************************************************************
 * [S]imulated [M]edieval [A]dventure multi[U]ser [G]ame      |   \\._.//   *
 * -----------------------------------------------------------|   (0...0)   *
 * SMAUG 1.0 (C) 1994, 1995, 1996, 1997 by Derek Snider       |    ).:.(    *
 * -----------------------------------------------------------|    {o o}    *
 * SMAUG code team: Thoric, Altrag, Blodkai, Narn, Haus,      |   / ' ' \   *
 * Scryn, Rennard, Swordbearer, Gorog, Grishnakh and Tricops  |~'~.VxvxV.~'~*
 ****************************************************************************

I admit it... most of the SMAUG code is very poorly documented.
This is because most of the effort was spent on coding, and very little
on documenting.

I have gone over all the text files in this directory, and done my best
to update them what little spare time I had.

Due to the ability to edit most everything online, you will most likely
find the online help pages more informative.

(You should find WIZHELP, HELP and HLIST very useful)


We have a mailing list set up to help you with any problems you may have
porting the code, getting it compile, bugs, comments, suggestions, etc.

To join the list, send an email to smaug-request@realms.game.org with the
word "subscribe" in the body of the message.

-Thoric
