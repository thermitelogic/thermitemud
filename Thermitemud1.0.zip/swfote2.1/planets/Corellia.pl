#PLANET
Name         Corellia~
Filename     Corellia.pl~
X            1000
Y            -1567
Z            26
Sector       0
Type    	   0
PopSupport   96
Starsystem   Corell~
GovernedBy   The Empire~
Area         Corellia.are~
Resource 1 0 0 0 0 0
Resource 2 0 0 0 0 0
Resource 3 0 0 0 0 0
Resource 4 0 0 0 0 0
Resource 5 0 0 0 0 0
Resource 6 0 0 0 0 0
Resource 7 0 0 0 0 0
End

#END
