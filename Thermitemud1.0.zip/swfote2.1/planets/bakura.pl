#PLANET
Name         Bakura~
Filename     bakura.pl~
X            1001
Y            -520
Z            -1850
Sector       0
Type    	   0
PopSupport   98
Starsystem   Bakur~
GovernedBy   The Empire~
Area         bakura.are~
Resource 1 0 0 0 0 0
Resource 2 0 0 0 0 0
Resource 3 0 0 0 0 0
Resource 4 0 0 0 0 0
Resource 5 0 0 0 0 0
Resource 6 0 0 0 0 0
Resource 7 0 0 0 0 0
End

#END
