#PLANET
Name         Tatooine~
Filename     Tatooine.pl~
X            -1460
Y            -19001
Z            -1890
Sector       0
Type    	   0
PopSupport   92
Starsystem   Outer Rim~
GovernedBy   The Empire~
Area         tatooine.are~
Area         sith.are~
Resource 1 0 0 0 0 0
Resource 2 0 0 0 0 0
Resource 3 0 0 0 0 0
Resource 4 0 0 0 0 0
Resource 5 0 0 0 0 0
Resource 6 0 0 0 0 0
Resource 7 0 0 0 0 0
End

#END
