#PLANET
Name         Coruscant~
Filename     Coruscant.pl~
X            -345
Y            -987
Z            1562
Sector       0
Type    	   0
PopSupport   99
Starsystem   Coruscant~
GovernedBy   The Empire~
Area         coruscant.are~
Area         coruscant2.are~
Area         coruscant3.are~
Area         newbie.are~
Resource 1 0 0 0 0 0
Resource 2 0 0 0 0 0
Resource 3 0 0 0 0 0
Resource 4 0 0 0 0 0
Resource 5 0 0 0 0 0
Resource 6 0 0 0 0 0
Resource 7 0 0 0 0 0
End

#END
