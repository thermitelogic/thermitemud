#PLANET
Name         Kashyyyk~
Filename     Kashyyyk.pl~
X            1500
Y            -1397
Z            2230
Sector       0
Type    	   0
PopSupport   92
Starsystem   Kashyyyk~
GovernedBy   The Empire~
Area         kashyyyk.are~
Resource 1 0 0 0 0 0
Resource 2 0 0 0 0 0
Resource 3 0 0 0 0 0
Resource 4 0 0 0 0 0
Resource 5 0 0 0 0 0
Resource 6 0 0 0 0 0
Resource 7 0 0 0 0 0
End

#END
