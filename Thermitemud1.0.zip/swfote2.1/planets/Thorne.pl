#PLANET
Name         Thorne Asteroid~
Filename     Thorne.pl~
X            -10002
Y            210
Z            1980
Sector       0
Type    	   0
PopSupport   100
Starsystem   Byss~
GovernedBy   Neutral~
Area         silenceindustries.are~
Resource 1 0 0 0 0 0
Resource 2 0 0 0 0 0
Resource 3 0 0 0 0 0
Resource 4 0 0 0 0 0
Resource 5 0 0 0 0 0
Resource 6 0 0 0 0 0
Resource 7 0 0 0 0 0
End

#END
