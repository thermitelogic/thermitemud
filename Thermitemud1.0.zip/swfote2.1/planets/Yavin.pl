#PLANET
Name         Yavin IV~
Filename     Yavin.pl~
X            4000
Y            4000
Z            4000
Sector       0
Type    	   0
PopSupport   100
Starsystem   Yavin IV~
GovernedBy   Neutral~
Area         Yavin.are~
Resource 1 0 0 0 0 0
Resource 2 0 0 0 0 0
Resource 3 0 0 0 0 0
Resource 4 0 0 0 0 0
Resource 5 0 0 0 0 0
Resource 6 0 0 0 0 0
Resource 7 0 0 0 0 0
End

#END
